﻿using System;

namespace VSA1_Lab1_LinkedList
{
    public class Node
    {
        public int Data { get; set; }
        public Node Next { get; set; }
        public Node(int data)
        {
            Data = data;
            Next = null;}

    }
    class Program
    {
        static void Main(string[] args)
        {
            Node testNode = new Node(15);
            Console.WriteLine("node yaradildi");
            Console.WriteLine($"Datanin qiymeti{testNode.Data}");
            Console.WriteLine($"Next gosterici: {testNode.Next}");
        }
    }
}