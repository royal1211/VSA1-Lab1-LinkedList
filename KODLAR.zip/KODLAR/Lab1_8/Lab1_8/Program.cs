﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_8
{
    public class Node
    {
        public int data;
        public Node next;

        public Node(int data)
        {
            this.data = data;
            this.next = null;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Node head = new Node(10);
            head.next = new Node(45);
            head.next.next = new Node(20);
            head.next.next.next = new Node(30);

            Console.Write("Siyahi;");
            Node current = head;
            while (current != null)
            {
                Console.Write(current.data + " >");
                current = current.next;
            }
            Console.WriteLine("None");

            int max = head.data;
            current = head;
            while (current != null)
            {
                if (current.data > max)
                {
                    max = current.data;
                }
                current = current.next;
            }
            int min = head.data;
            current = head;
            while (current != null)
            {
                if (current.data<min)
                {
                    min = current.data;
                }
                current = current.next;
            }
            Console.WriteLine("En boyuk element;" + max);
            Console.WriteLine("En kicik element;" + min);
        }
    }
}
