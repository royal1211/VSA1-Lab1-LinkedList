﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Lab1_4
{
        public class Node
        {
            public int data;
            public Node next;

            public Node(int data)
            {
                this.data = data;
                this.next = null;
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Node head = new Node(10);
                head.next = new Node(20);
                head.next.next = new Node(40);
                Console.Write("evvel;");
                Node current = head;
                while (current != null)
                {
                    Console.Write(current.data + ">");
                    current = current.next;
                }
                Console.WriteLine("None");
                Node newNode = new Node(30);
                newNode.next = head.next.next; 
                head.next.next = newNode;     
                Console.Write("Sonra;");
                current = head;
                while (current != null)
                {
                    Console.Write(current.data + ">");
                    current = current.next;
                }
                Console.WriteLine("None");
            }
        }
    }