﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_6
{
    public class Node
    {
        public int data;
        public Node next;

        public Node(int data)
        {
            this.data = data;
            this.next = null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Node head = new Node(10);
            head.next = new Node(20);
            head.next.next = new Node(30);
            head.next.next.next = new Node(40);
            Console.Write("Siyahi;");
            Node current = head;
            while (current != null)
            {
                Console.Write(current.data + ">");
                current = current.next;
            }
            Console.WriteLine("None");
            int target = 30;
            bool found = false;
            current = head;

            while (current != null)
            {
                if (current.data == target)
                {
                    found = true;
                    break;
                }
                current = current.next;
            }
            if (found)
            {
                Console.WriteLine("Element tapildi;"+ target);
            }
            else
            {
                Console.WriteLine("Element tapilmadi");
            }
        }
    }
}
